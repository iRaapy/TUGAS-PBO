class Item:
    def __init__(self, item_id, title, year):
        self.id = item_id
        self.title = title
        self.year = year
        self.status = 'available'

    def get_info(self):
        return f"ID: {self.id}, Title: {self.title}, Year: {self.year}, Status: {self.status}"

class Book(Item):
    def __init__(self, item_id, title, year, author, isbn, pages):
        super().__init__(item_id, title, year)
        self.author = author
        self.isbn = isbn
        self.pages = pages

    def get_info(self):
        return super().get_info() + f", Author: {self.author}, ISBN: {self.isbn}, Pages: {self.pages}"

class DVD(Item):
    def __init__(self, item_id, title, year, director, duration_min):
        super().__init__(item_id, title, year)
        self.director = director
        self.duration_min = duration_min

    def get_info(self):
        return super().get_info() + f", Director: {self.director}, Duration: {self.duration_min} min"

class Magazine(Item):
    def __init__(self, item_id, title, year, issue):
        super().__init__(item_id, title, year)
        self.issue = issue

    def get_info(self):
        return super().get_info() + f", Issue: {self.issue}"
