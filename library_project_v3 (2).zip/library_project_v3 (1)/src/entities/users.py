class User:
    def __init__(self, user_id, name):
        self.user_id = user_id
        self.name = name

    def get_info(self):
        return f"ID: {self.user_id}, Name: {self.name}"

class Member(User):
    def __init__(self, user_id, name, max_loans=3):
        super().__init__(user_id, name)
        self.max_loans = max_loans

class Librarian(User):
    def __init__(self, user_id, name):
        super().__init__(user_id, name)
