from datetime import datetime, timedelta
from utils.helpers import format_date

class LoanTransaction:
    def __init__(self, tx_id, member, item, due_date):
        self.tx_id = tx_id
        self.member = member
        self.item = item
        self.due_date = due_date
        self.returned_date = None

class LoanManager:
    def __init__(self):
        self.loans = []
        self.tx_id_counter = 1

    def create_loan(self, member, item, days=7):
        if item.status != 'available':
            raise Exception(f"Item {item.id} is not available for loan.")
        if len([loan for loan in self.loans if loan.member == member]) >= member.max_loans:
            raise Exception(f"Member {member.user_id} has reached the loan limit.")
        
        due_date = datetime.now() + timedelta(days=days)
        tx = LoanTransaction(self.tx_id_counter, member, item, due_date)
        self.tx_id_counter += 1

        item.status = 'on loan'
        self.loans.append(tx)

        return tx

    def close_loan(self, tx_id):
        loan = next((loan for loan in self.loans if loan.tx_id == tx_id), None)
        if loan:
            loan.returned_date = datetime.now()
            loan.item.status = 'available'
            return loan
        return None

    def list_overdue(self):
        return [loan for loan in self.loans if loan.due_date < datetime.now() and loan.returned_date is None]
