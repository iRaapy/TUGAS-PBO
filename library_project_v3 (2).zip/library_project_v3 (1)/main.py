import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from entities.items import Book, DVD, Magazine
from entities.users import Member, Librarian
from managers.catalog import Catalog
from managers.loan_manager import LoanManager
from utils.helpers import format_date

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.traceback import install
from rich import box
from rich.align import Align

install()
console = Console()

def show_catalog(catalog: Catalog):
    table = Table(title="Katalog Perpustakaan", box=box.SIMPLE_HEAVY)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Title", style="bold")
    table.add_column("Year", justify="right")
    table.add_column("Type")
    table.add_column("Status", style="green")
    table.add_column("Details", overflow="fold")

    for it in catalog.list_all():
        typ = "Book" if isinstance(it, Book) else "DVD" if isinstance(it, DVD) else "Magazine"
        table.add_row(it.id, it.title, str(it.year), typ, it.status, it.get_info())

    console.print(table)

def show_member_info(member: Member):
    console.print(Panel.fit(member.get_info(), title=f"Member: {member.user_id}", subtitle=member.name))

def show_loan_panel(tx, title="Loan Created"):
    body = f"[bold]TX:[/bold] {tx.tx_id}\n[bold]Item:[/bold] {tx.item.id} — {tx.item.title}\n[bold]Member:[/bold] {tx.member.user_id} — {tx.member.name}\n[bold]Due:[/bold] {format_date(tx.due_date)}"
    console.print(Panel(body, title=title, style="magenta"))

def main():
    catalog = Catalog()
    lm = LoanManager()

    # create users
    lib = Librarian('lib001', 'Siti')
    m1 = Member('m001', 'Andi', max_loans=2)
    m2 = Member('m002', 'Budi', max_loans=1)

    # create items
    b1 = Book('B001', 'Dasar Pemrograman', 2020, author='A. Programmer', isbn='978-0-111', pages=320)
    d1 = DVD('D001', 'Documentary X', 2018, director='C. Director', duration_min=90)
    mag1 = Magazine('M001', 'Science Monthly', 2021, issue='Vol.10 No.4')

    for it in (b1, d1, mag1):
        catalog.add_item(it)

    console.rule("[bold cyan]Daftar Item[/bold cyan]")
    show_catalog(catalog)

    console.rule("[bold green]Proses Peminjaman[/bold green]")
    with console.status("Membuat loan...", spinner="dots"):
        tx = lm.create_loan(m1, b1, days=7)
    show_loan_panel(tx)
    console.print(f"Status item setelah dipinjam: [bold yellow]{b1.status}[/bold yellow]")
    show_member_info(m1)

    # Coba pinjam item yang sudah dipinjam -> error
    try:
        lm.create_loan(m2, b1)
    except Exception as e:
        console.print(Panel(f"[red]Gagal pinjam (seharusnya):[/red]\n{e}", title="Error", style="red"))

    # Kembalikan
    closed = lm.close_loan(tx.tx_id)
    console.rule("[bold blue]Pengembalian[/bold blue]")
    console.print(Panel(f"Loan [bold]{closed.tx_id}[/bold] dikembalikan pada [bold]{format_date(closed.returned_date)}[/bold]\nStatus item: [green]{b1.status}[/green]", title="Return Info"))
    show_member_info(m1)

    # Simulasikan overdue
    tx2 = lm.create_loan(m1, d1, days=1)
    # force overdue
    try:
        tx2.due_date = tx2.due_date.replace(year=tx2.due_date.year - 1)
    except Exception:
        # safe fallback if due_date is date not datetime
        from datetime import date
        tx2.due_date = date(tx2.due_date.year - 1, tx2.due_date.month, tx2.due_date.day)

    overdue = lm.list_overdue()
    if overdue:
        table = Table(title="Daftar Overdue", box=box.MINIMAL_DOUBLE_HEAD)
        table.add_column("TX", style="red")
        table.add_column("Item")
        table.add_column("Member")
        table.add_column("Due", style="yellow")
        for o in overdue:
            table.add_row(o.tx_id, f"{o.item.id} ({o.item.title})", f"{o.member.user_id} ({o.member.name})", format_date(o.due_date))
        console.print(table)
    else:
        console.print(Panel("Tidak ada overdue saat ini.", style="green"))

if __name__ == '__main__':
    main()
