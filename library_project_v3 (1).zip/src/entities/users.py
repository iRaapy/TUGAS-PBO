"""entities.users - User base class, Member and Librarian"""
from typing import List, Optional

class User:
    def __init__(self, user_id: str, name: str):
        self.__user_id = user_id
        self.__name = name

    @property
    def user_id(self) -> str:
        return self.__user_id

    @property
    def name(self) -> str:
        return self.__name

    def get_contact(self) -> str:
        return f"{self.__name} ({self.__user_id})"


class Member(User):
    def __init__(self, user_id: str, name: str, max_loans: int = 3):
        super().__init__(user_id, name)
        self.__max_loans = max_loans
        self.__current_loans: List[str] = []

    def can_borrow(self) -> bool:
        return len(self.__current_loans) < self.__max_loans

    def borrow_success(self, item_id: str):
        self.__current_loans.append(item_id)

    def return_success(self, item_id: str):
        if item_id in self.__current_loans:
            self.__current_loans.remove(item_id)

    def list_current_loans(self) -> List[str]:
        return list(self.__current_loans)

    def get_info(self) -> str:
        return f"[Member] {self.user_id} - {self.name}, loans={len(self.__current_loans)}/{self.__max_loans}"


class Librarian(User):
    def __init__(self, user_id: str, name: str):
        super().__init__(user_id, name)

    def get_info(self) -> str:
        return f"[Librarian] {self.user_id} - {self.name}"
