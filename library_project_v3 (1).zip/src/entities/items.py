"""entities.items - Item base class and subclasses: Book, DVD, Magazine"""
from typing import Optional

class Item:
    def __init__(self, item_id: str, title: str, year: int):
        self.__id = item_id
        self.__title = title
        self.__year = year
        self.__status = "available"  # available / borrowed / reserved / lost

    # Encapsulation: properties
    @property
    def id(self) -> str:
        return self.__id

    @property
    def title(self) -> str:
        return self.__title

    @property
    def year(self) -> int:
        return self.__year

    @property
    def status(self) -> str:
        return self.__status

    def set_status(self, new_status: str):
        if new_status not in ("available", "borrowed", "reserved", "lost"):
            raise ValueError("Invalid status")
        self.__status = new_status

    def is_available(self) -> bool:
        return self.__status == "available"

    # Polymorphic method
    def get_info(self) -> str:
        return f"[Item] {self.__id} - {self.__title} ({self.__year}) status={self.__status}"


class Book(Item):
    def __init__(self, item_id: str, title: str, year: int, author: str, isbn: str, pages: int):
        super().__init__(item_id, title, year)
        self.__author = author
        self.__isbn = isbn
        self.__pages = pages

    @property
    def author(self) -> str:
        return self.__author

    def get_info(self) -> str:
        return f"[Book] {self.id} - '{self.title}' by {self.__author} ({self.year}) ISBN:{self.__isbn} status={self.status}"


class DVD(Item):
    def __init__(self, item_id: str, title: str, year: int, director: str, duration_min: int):
        super().__init__(item_id, title, year)
        self.__director = director
        self.__duration = duration_min

    def get_info(self) -> str:
        return f"[DVD] {self.id} - '{self.title}' directed by {self.__director} ({self.year}) {self.__duration}min status={self.status}"


class Magazine(Item):
    def __init__(self, item_id: str, title: str, year: int, issue: str):
        super().__init__(item_id, title, year)
        self.__issue = issue

    def get_info(self) -> str:
        return f"[Magazine] {self.id} - '{self.title}' Issue:{self.__issue} ({self.year}) status={self.status}"
