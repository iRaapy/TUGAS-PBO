"""managers.catalog - Catalog class to manage items"""
from typing import List, Dict, Optional
from entities.items import Item

class Catalog:
    def __init__(self):
        self._items: Dict[str, Item] = {}

    def add_item(self, item: Item):
        if item.id in self._items:
            raise KeyError(f"Item with id {item.id} already exists")
        self._items[item.id] = item

    def remove_item(self, item_id: str):
        if item_id not in self._items:
            raise KeyError("Item not found")
        del self._items[item_id]

    def get_item(self, item_id: str) -> Optional[Item]:
        return self._items.get(item_id)

    def search_by_title(self, text: str) -> List[Item]:
        text_lower = text.lower()
        return [it for it in self._items.values() if text_lower in it.title.lower()]

    def list_all(self) -> List[Item]:
        return list(self._items.values())
