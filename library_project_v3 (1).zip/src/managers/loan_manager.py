"""managers.loan_manager - LoanManager and LoanTransaction"""
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from entities.users import Member
from entities.items import Item

class LoanTransaction:
    def __init__(self, tx_id: str, member: Member, item: Item, loan_date: datetime, due_date: datetime):
        self.tx_id = tx_id
        self.member = member
        self.item = item
        self.loan_date = loan_date
        self.due_date = due_date
        self.returned_date: Optional[datetime] = None

    def is_overdue(self, on_date: Optional[datetime] = None) -> bool:
        if self.returned_date is not None:
            return self.returned_date > self.due_date
        check_date = on_date or datetime.now()
        return check_date > self.due_date

    def mark_returned(self, returned_date: Optional[datetime] = None):
        self.returned_date = returned_date or datetime.now()


class LoanManager:
    def __init__(self):
        self._loans: Dict[str, LoanTransaction] = {}
        self._next_tx = 1

    def _make_tx_id(self) -> str:
        tx = f"TX{self._next_tx:05d}"
        self._next_tx += 1
        return tx

    def create_loan(self, member: Member, item: Item, days: int = 14) -> LoanTransaction:
        if not item.is_available():
            raise Exception("Item not available")
        if not member.can_borrow():
            raise Exception("Member has reached loan limit")
        tx_id = self._make_tx_id()
        loan_date = datetime.now()
        due_date = loan_date + timedelta(days=days)
        tx = LoanTransaction(tx_id, member, item, loan_date, due_date)
        self._loans[tx_id] = tx
        item.set_status("borrowed")
        member.borrow_success(item.id)
        return tx

    def close_loan(self, tx_id: str) -> LoanTransaction:
        tx = self._loans.get(tx_id)
        if not tx:
            raise KeyError("Loan not found")
        if tx.returned_date is not None:
            raise Exception("Loan already closed")
        tx.mark_returned()
        tx.item.set_status("available")
        tx.member.return_success(tx.item.id)
        return tx

    def find_loans_by_member(self, member: Member) -> List[LoanTransaction]:
        return [tx for tx in self._loans.values() if tx.member.user_id == member.user_id and tx.returned_date is None]

    def list_overdue(self, on_date: Optional[datetime] = None) -> List[LoanTransaction]:
        return [tx for tx in self._loans.values() if tx.is_overdue(on_date) and tx.returned_date is None]
