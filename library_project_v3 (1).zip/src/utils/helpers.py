"""utils.helpers - helper utilities for the project"""
from datetime import datetime

def format_date(dt: datetime) -> str:
    return dt.strftime('%Y-%m-%d %H:%M:%S')
