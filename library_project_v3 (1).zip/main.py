# Demo script to exercise the library project
from entities.items import Book, DVD, Magazine
from entities.users import Member, Librarian
from managers.catalog import Catalog
from managers.loan_manager import LoanManager
from utils.helpers import format_date

def main():
    catalog = Catalog()
    lm = LoanManager()

    # create users
    lib = Librarian('lib001', 'Siti')
    m1 = Member('m001', 'Andi', max_loans=2)
    m2 = Member('m002', 'Budi', max_loans=1)

    # create items
    b1 = Book('B001', 'Dasar Pemrograman', 2020, author='A. Programmer', isbn='978-0-111', pages=320)
    d1 = DVD('D001', 'Documentary X', 2018, director='C. Director', duration_min=90)
    mag1 = Magazine('M001', 'Science Monthly', 2021, issue='Vol.10 No.4')

    for it in (b1, d1, mag1):
        catalog.add_item(it)

    print('--- Semua item di katalog ---')
    for it in catalog.list_all():
        print(it.get_info())

    print('\n--- Membuat loan untuk Andi ---')
    tx = lm.create_loan(m1, b1, days=7)
    print(f'Loan dibuat: {tx.tx_id} untuk item {tx.item.id}, due {tx.due_date.date()}')
    print('Status item setelah dipinjam:', b1.status)
    print('Info member:', m1.get_info())

    # Coba pinjam item yang sudah dipinjam -> error
    try:
        lm.create_loan(m2, b1)
    except Exception as e:
        print('Gagal pinjam (seharusnya):', e)

    # Kembalikan
    closed = lm.close_loan(tx.tx_id)
    print('\n--- Kembalikan item ---')
    print(f'Loan {closed.tx_id} dikembalikan pada {format_date(closed.returned_date)}')
    print('Status item setelah dikembalikan:', b1.status)
    print('Info member setelah pengembalian:', m1.get_info())

    # Simulasikan overdue
    tx2 = lm.create_loan(m1, d1, days=1)
    tx2.due_date = tx2.due_date.replace(year=tx2.due_date.year - 1)  # force overdue
    overdue = lm.list_overdue()
    print('\n--- Daftar overdue ---')
    for o in overdue:
        print(f"{o.tx_id} item={o.item.id} member={o.member.user_id} due={o.due_date.date()}")


if __name__ == '__main__':
    main()
